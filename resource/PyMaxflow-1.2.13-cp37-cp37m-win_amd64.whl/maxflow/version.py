# -*- encoding:utf-8 -*-

__version__ = (1, 2, 13)
__version_str__ = ".".join(map(str, __version__))
__version_core__ = (3, 0, 4)
